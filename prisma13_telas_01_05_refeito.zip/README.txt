PRISMA13 · Telas 01-05 refeitas

Estrutura:
- public/index.html              = Tela01 · Frontispício
- public/tela02/index.html       = Tela02 · Identificação PUP13
- public/tela03/index.html       = Tela03 · Leitura Biológica Inicial
- public/tela04/index.html       = Tela04 · Matriz Canônica
- public/tela05/index.html       = Tela05 · Métrica Consciente
- firebase.json                  = configuração básica para Firebase Hosting

Critérios aplicados:
- rodapé padrão da Tela01 preservado e com selos justapostos às frases;
- telas 02-05 com faixa superior LGPD DO PLANO PUP13;
- retirada das informações soltas de topo: PRISMA13 / Ingresso da PUP13 / SOL - IMC22;
- estética preta, branca, ouro, minimalista, ritualística e menos “formulário comum”;
- cada tela é bloco único, sem dependências externas.

Deploy Firebase:
1. Copie a pasta public e o firebase.json para a raiz do projeto.
2. Rode: firebase deploy
3. Abra a URL do Hosting.
